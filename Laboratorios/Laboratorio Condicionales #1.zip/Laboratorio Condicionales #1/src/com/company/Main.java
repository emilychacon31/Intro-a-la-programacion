package com.company;
import javax.swing.JOptionPane;
public class Main
{

    public static void main(String[] args)
    {
        int UltimoDigito;

        UltimoDigito=Integer.parseInt(JOptionPane.showInputDialog("Hola ingrese el ultimo digito de su placa"));

        if (UltimoDigito==1 || UltimoDigito==2)
        {
            JOptionPane.showMessageDialog(null, "No puede circular el lunes");
        }
        else if(UltimoDigito==3|| UltimoDigito==4)
        {
            JOptionPane.showMessageDialog(null, "No puede circular el Martes");

        }
        else if(UltimoDigito==5|| UltimoDigito==6)
        {
            JOptionPane.showMessageDialog(null, "No puede circular el Miercoles");

        }
        else if(UltimoDigito==7|| UltimoDigito==8)
        {
            JOptionPane.showMessageDialog(null, "No puede circular el Jueves");

        }
        else if(UltimoDigito==9|| UltimoDigito==0)
        {
            JOptionPane.showMessageDialog(null, "No puede circular el Viernes");

        }

        if (UltimoDigito%2==0)
        {
            JOptionPane.showMessageDialog(null, "No puede circular los sabados");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "No puede circular los domingos");
        }



    }












}
