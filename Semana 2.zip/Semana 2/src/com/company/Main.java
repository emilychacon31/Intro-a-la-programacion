package com.company;
import javax.swing.JOptionPane;

public class Main
{


    public static void main(String[] args)
    {


        /*int SAT;
        SAT = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese un numero"));
        if (SAT >= 800)
        {
            JOptionPane.showMessageDialog(null, "Puedes elegir las siguientes carreras: Medicina, Informatica, Enfermeria");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Puedes elegir solo carreras tecnicas");
        }*/

        /*int numero = 25;
        int elSegundoNumero= 30;
        if (numero== 25&& elSegundoNumero==30) // Verdadero Falso || Verdadero and &&
        {
            System.out.println("numeros son iguales");

        }*/
        /*int Edad;
        Edad = Integer.parseInt(JOptionPane.showInputDialog(null,"Hola, Ingrese su edad"));
        if (Edad >= 18)
        {
            JOptionPane.showMessageDialog(null, "La persona es mayor de edad, por lo tanto, puede Votar");

        }
        else
        {
            JOptionPane.showMessageDialog(null, "La persona es menor de edad, No puede votar");

        }*/

        /*int Provincia;
        Provincia= Integer.parseInt(JOptionPane.showInputDialog(null,"Hola, ingrese la provincia donde reside: \n 1.San José \n 2.Alajuela \n 3.Heredia \n 4.Cartago \n 5.Limon \n 6. Guanacaste \n Puntarenas" ));
        if (Provincia ==1)
        {
            JOptionPane.showMessageDialog(null, "Usted reside en San José");
        }
        else if (Provincia ==2)
        {
            JOptionPane.showMessageDialog(null, "Usted reside en Alajuela");
        }
        else if (Provincia ==3)
        {
            JOptionPane.showMessageDialog(null, "Usted reside en Heredia");
        }
        else if (Provincia ==4)
        {
            JOptionPane.showMessageDialog(null, "Usted reside en Cartago");
        }
        else if (Provincia ==5)
        {
            JOptionPane.showMessageDialog(null, "Usted reside en Limón");
        }
        else if (Provincia ==6)
        {
            JOptionPane.showMessageDialog(null, "Usted reside Guanacaste");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Usted reside en Puntarenas");
        } */

        /*int dia;
        dia= Integer.parseInt(JOptionPane.showInputDialog(null,"Hola, ingrese el numero del dia: \n 1.Lunes \n 2.Martes \n 3.Miercoles \n 4.Jueves \n 5.Viernes \n 6. Sabado \n Domingo" ));
        if (dia ==1)
        {
            JOptionPane.showMessageDialog(null, "Es Lunes, es día laboral");
        }
        else if (dia ==2)
        {
            JOptionPane.showMessageDialog(null, "Es martes, es día laboral");
        }
        else if (dia ==3)
        {
            JOptionPane.showMessageDialog(null, "Es miercoles, es día laboral");
        }
        else if (dia ==4)
        {
            JOptionPane.showMessageDialog(null, "Es Jueves, es día laboral");
        }
        else if (dia ==5)
        {
            JOptionPane.showMessageDialog(null, "Es viernes, es día laboral");
        }
        else if (dia ==6)
        {
            JOptionPane.showMessageDialog(null, "Es sábado, es día libre");
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Es domingo, es día libre");
        }
        */
        double precio;
        precio= Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el precio"));
        JOptionPane.showMessageDialog(null, "El precio originalmente era de:"+precio);
        JOptionPane.showMessageDialog(null, "El precio redondeado es de:"+ Math.round(precio));









    }

}
