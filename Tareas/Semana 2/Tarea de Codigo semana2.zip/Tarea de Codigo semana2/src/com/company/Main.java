package com.company;
import javax.swing.JOptionPane;
public class Main
{

    public static void main(String[] args)
    {
        int añosAnt;
        int horasSem;
        double precioxh;
        añosAnt= Integer.parseInt(JOptionPane.showInputDialog("Hola, ingrese los años de antiguedad laborados en la empresa"));
        horasSem= Integer.parseInt(JOptionPane.showInputDialog("Ingrese las horas laboradas por semana"));
        precioxh=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio por hora"));

        double SalarioBruto= (horasSem*precioxh);
        double deducciones;
        double bono;
        if (añosAnt>10)
        {
            bono= (SalarioBruto*20/100)+SalarioBruto;
        }
        else
        {
            bono=0;
        }
        double NuevoSalario= (SalarioBruto+bono);

        if(NuevoSalario>1000)
        {
            deducciones= (NuevoSalario*10/100);
        }
        else if(NuevoSalario>2000)
        {
            deducciones= (NuevoSalario*15/100);
        }
        else
        {
            deducciones=0;
        }

        double SalarioNeto= NuevoSalario-deducciones;
        JOptionPane.showMessageDialog(null, "El Salario Neto es:"+SalarioNeto);
    }
}
