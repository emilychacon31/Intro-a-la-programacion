package com.company;

import javax.swing.JOptionPane;

public class Main
{

    public static void main(String[] args)
    {
        Double sueldo;
        String nombre;
        Double deduciones;
        Double salarioNeto;

        nombre= JOptionPane.showInputDialog("Hola, ingrese su nombre");
        sueldo= Double.parseDouble(JOptionPane.showInputDialog(nombre+", ingrese su salario"));

        deduciones= (sueldo*9.34)/100;
        salarioNeto= sueldo-deduciones;
        JOptionPane.showMessageDialog(null, "Estimado trabajador "+ nombre+
                ", el salario de este mes se desglosa de la siguiente manera: \n Salario Bruto:"+sueldo+"\n Deducciones:"+deduciones+"\n Salario Neto:"+salarioNeto);





    }


}
